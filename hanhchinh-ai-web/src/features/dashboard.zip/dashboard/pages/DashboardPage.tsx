import DashboardHero from "../components/DashboardHero";
import DashboardStats from "../components/DashboardStats";
import QuickActions from "../components/QuickActions";
import RecentActivities from "../components/RecentActivities";

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      {/* Hero */}
      <DashboardHero />

      {/* Thống kê */}
      <DashboardStats />

      {/* Nội dung chính */}
      <div className="grid gap-8 xl:grid-cols-5">
        {/* Thao tác nhanh */}
        <div className="xl:col-span-2">
          <QuickActions />
        </div>

        {/* Hoạt động gần đây */}
        <div className="xl:col-span-3">
          <RecentActivities />
        </div>
      </div>
    </div>
  );
}