import {
  Bot,
  FileSearch,
  FileText,
  Files,
  FolderOpen,
  Users,
} from "lucide-react";

export const dashboardStats = [
  {
    title: "Văn bản",
    value: 32,
    description: "Đã tạo hôm nay",
    icon: FileText,
  },
  {
    title: "AI hỗ trợ",
    value: 128,
    description: "Lượt sử dụng",
    icon: Bot,
  },
  {
    title: "Hồ sơ",
    value: 18,
    description: "Đang xử lý",
    icon: FolderOpen,
  },
  {
    title: "Người dùng",
    value: 6,
    description: "Đang hoạt động",
    icon: Users,
  },
];

export const quickActions = [
  {
    title: "Soạn Công văn",
    description: "AI hỗ trợ soạn công văn",
    icon: FileText,
  },
  {
    title: "Trợ lý AI",
    description: "Hỏi đáp nghiệp vụ",
    icon: Bot,
  },
  {
    title: "Tóm tắt PDF",
    description: "Phân tích văn bản",
    icon: FileSearch,
  },
  {
    title: "Mẫu văn bản",
    description: "Quản lý Template",
    icon: Files,
  },
];

export const recentActivities = [
  {
    id: 1,
    title: "Soạn Công văn",
    description: "AI đã tạo Công văn số 25/CV-UBND",
    time: "08:30",
    icon: FileText,
  },
  {
    id: 2,
    title: "Tóm tắt PDF",
    description: "Đã tóm tắt văn bản",
    time: "09:15",
    icon: Bot,
  },
  {
    id: 3,
    title: "Xuất Word",
    description: "Xuất file Word thành công",
    time: "10:02",
    icon: Files,
  },
];