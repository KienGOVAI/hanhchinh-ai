import { Sparkles } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function DashboardHero() {
  const today = new Intl.DateTimeFormat("vi-VN", {
    weekday: "long",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(new Date());

  return (
    <Card className="overflow-hidden border-primary/20 bg-gradient-to-r from-primary/10 via-background to-background">
      <CardContent className="flex flex-col gap-6 p-6 md:flex-row md:items-center md:justify-between">
        <div className="space-y-3">
          <Badge variant="secondary" className="w-fit">
            <Sparkles className="mr-1 h-4 w-4" />
            Hành Chính AI
          </Badge>

          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Xin chào, Nguyễn Trung Kiên 👋
            </h1>

            <p className="mt-2 text-muted-foreground">
              Chúc bạn một ngày làm việc hiệu quả cùng hệ thống Hành Chính AI.
            </p>
          </div>

          <p className="text-sm text-muted-foreground">
            {today}
          </p>
        </div>

        <div className="rounded-xl border bg-background/70 p-5 shadow-sm backdrop-blur">
          <p className="text-sm text-muted-foreground">
            Trạng thái hệ thống
          </p>

          <div className="mt-2 flex items-center gap-2">
            <span className="h-3 w-3 rounded-full bg-green-500" />

            <span className="font-medium">
              Hoạt động bình thường
            </span>
          </div>

          <p className="mt-2 text-sm text-muted-foreground">
            FastAPI • Ollama • PostgreSQL
          </p>
        </div>
      </CardContent>
    </Card>
  );
}