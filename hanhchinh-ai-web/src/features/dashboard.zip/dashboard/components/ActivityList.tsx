import {
  Bot,
  FileCheck,
  FileText,
  FileUp,
} from "lucide-react";

interface Activity {
  id: number;
  title: string;
  description: string;
  time: string;
  icon: React.ReactNode;
}

const activities: Activity[] = [
  {
    id: 1,
    title: "Soạn Công văn",
    description: "AI đã tạo Công văn số 25/CV-UBND",
    time: "08:30",
    icon: <FileText className="h-5 w-5" />,
  },
  {
    id: 2,
    title: "Tóm tắt văn bản",
    description: "Đã tóm tắt file PDF thành công",
    time: "09:15",
    icon: <Bot className="h-5 w-5" />,
  },
  {
    id: 3,
    title: "Xuất Word",
    description: "Đã xuất văn bản .docx",
    time: "10:02",
    icon: <FileUp className="h-5 w-5" />,
  },
  {
    id: 4,
    title: "Kiểm tra thể thức",
    description: "Không phát hiện lỗi thể thức",
    time: "10:45",
    icon: <FileCheck className="h-5 w-5" />,
  },
];

export default function ActivityList() {
  return (
    <div className="rounded-2xl border bg-card p-6 shadow-sm">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">
            Hoạt động gần đây
          </h2>

          <p className="text-sm text-muted-foreground">
            Các thao tác mới nhất trong hệ thống
          </p>
        </div>
      </div>

      <div className="space-y-5">
        {activities.map((activity) => (
          <div
            key={activity.id}
            className="
              flex
              items-start
              gap-4
              rounded-xl
              border
              p-4
              transition-all
              duration-300
              hover:bg-muted/40
            "
          >
            <div
              className="
                flex
                h-11
                w-11
                items-center
                justify-center
                rounded-full
                bg-primary/10
                text-primary
              "
            >
              {activity.icon}
            </div>

            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">
                  {activity.title}
                </h3>

                <span className="text-xs text-muted-foreground">
                  {activity.time}
                </span>
              </div>

              <p className="mt-1 text-sm text-muted-foreground">
                {activity.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}