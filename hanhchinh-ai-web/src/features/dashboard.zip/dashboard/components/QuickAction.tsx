import type { LucideIcon } from "lucide-react";

import { ChevronRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface QuickActionProps {
  title: string;
  description: string;
  icon: LucideIcon;
  onClick?: () => void;
}

export default function QuickAction({
  title,
  description,
  icon: Icon,
  onClick,
}: QuickActionProps) {
  return (
    <Card
      onClick={onClick}
      className="cursor-pointer transition-all hover:-translate-y-1 hover:shadow-md"
    >
      <CardContent className="flex items-center justify-between p-5">
        <div className="flex items-center gap-4">
          <div className="rounded-lg bg-primary/10 p-3">
            <Icon className="h-6 w-6 text-primary" />
          </div>

          <div>
            <h3 className="font-semibold">{title}</h3>

            <p className="text-sm text-muted-foreground">
              {description}
            </p>
          </div>
        </div>

        <ChevronRight className="h-5 w-5 text-muted-foreground" />
      </CardContent>
    </Card>
  );
}