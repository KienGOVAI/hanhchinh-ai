import ActivityItem from "./ActivityItem";
import { recentActivities } from "../data/dashboard.mock";

export default function RecentActivities() {
  return (
    <section className="space-y-4">
      <div>
        <h2 className="text-xl font-semibold tracking-tight">
          Hoạt động gần đây
        </h2>

        <p className="text-sm text-muted-foreground">
          Các thao tác mới nhất trên hệ thống.
        </p>
      </div>

      <div className="space-y-3">
        {recentActivities.map((activity) => (
          <ActivityItem
            key={activity.id}
            title={activity.title}
            description={activity.description}
            time={activity.time}
            icon={activity.icon}
          />
        ))}
      </div>
    </section>
  );
}