import type { LucideIcon } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";

interface ActivityItemProps {
  title: string;
  description: string;
  time: string;
  icon: LucideIcon;
}

export default function ActivityItem({
  title,
  description,
  time,
  icon: Icon,
}: ActivityItemProps) {
  return (
    <Card className="transition-shadow hover:shadow-sm">
      <CardContent className="flex items-start gap-4 p-4">
        <div className="rounded-lg bg-primary/10 p-2">
          <Icon className="h-5 w-5 text-primary" />
        </div>

        <div className="flex-1">
          <div className="flex items-center justify-between">
            <h3 className="font-medium">
              {title}
            </h3>

            <span className="text-xs text-muted-foreground">
              {time}
            </span>
          </div>

          <p className="mt-1 text-sm text-muted-foreground">
            {description}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}