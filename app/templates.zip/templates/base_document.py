"""
Base Document
-------------

Lớp cơ sở cho toàn bộ Template Engine.

Chịu trách nhiệm:

- Khởi tạo Document.
- Thiết lập Page.
- Thiết lập Font.
- Điều phối các Component.
"""

from docx import Document

from app.templates.styles import (
    ALIGN_CENTER,
    ALIGN_JUSTIFY,
    ALIGN_LEFT,
    ALIGN_RIGHT,
    apply_font,
    apply_normal_style,
    apply_page_style,
    apply_paragraph_style,
)


class BaseDocument:
    """
    Base class của toàn bộ Template.
    """

    def __init__(self):

        self.doc = Document()

        self._initialize()

    # =====================================================
    # INITIALIZE
    # =====================================================

    def _initialize(self) -> None:
        """
        Khởi tạo Document.
        """

        self.setup_page()

        self.setup_font()

    # =====================================================
    # PAGE
    # =====================================================

    def setup_page(self) -> None:
        """
        Thiết lập khổ giấy.
        """

        apply_page_style(self.doc)

    # =====================================================
    # FONT
    # =====================================================

    def setup_font(self) -> None:
        """
        Thiết lập font mặc định.
        """

        apply_normal_style(self.doc)

    # =====================================================
    # PARAGRAPH
    # =====================================================

    def paragraph(
        self,
        text: str = "",
        *,
        bold: bool = False,
        italic: bool = False,
        align=ALIGN_JUSTIFY,
        size: int = 13,
    ):
        """
        Thêm một Paragraph chuẩn.
        """

        paragraph = self.doc.add_paragraph()

        apply_paragraph_style(
            paragraph,
            align=align,
        )

        run = paragraph.add_run(text)

        apply_font(
            run,
            size=size,
            bold=bold,
            italic=italic,
        )

        return paragraph

    # =====================================================
    # TEXT
    # =====================================================

    def add_text(
        self,
        text: str,
        *,
        align=ALIGN_JUSTIFY,
    ) -> None:
        """
        Thêm nhiều đoạn văn.
        """

        for line in text.splitlines():

            line = line.strip()

            if not line:
                continue

            self.paragraph(
                text=line,
                align=align,
            )

    # =====================================================
    # HEADING
    # =====================================================

    def add_heading(
        self,
        text: str,
        level: int = 1,
        align=ALIGN_CENTER,
    ):
        """
        Thêm Heading.
        """

        heading_style = {
            1: (15, True),
            2: (14, True),
            3: (13, True),
        }

        size, bold = heading_style.get(
            level,
            (13, False),
        )

        paragraph = self.doc.add_paragraph()

        apply_paragraph_style(
            paragraph,
            align=align,
            indent=False,
        )

        run = paragraph.add_run(text)

        apply_font(
            run,
            size=size,
            bold=bold,
        )

        return paragraph

    # =====================================================
    # DOCUMENT API
    # =====================================================

    def create_content(
        self,
        text: str,
    ) -> None:
        """
        Sinh nội dung văn bản.
        """

        self.add_text(text)

    def blank(
        self,
        lines: int = 1,
    ) -> None:
        """
        Chèn dòng trắng.
        """

        for _ in range(lines):
            self.doc.add_paragraph()

    def save(
        self,
        path: str,
    ) -> None:
        """
        Lưu file Word.
        """

        self.doc.save(path)